#include "ps_func.h"

Ps_Func::Ps_Func()
{

}

