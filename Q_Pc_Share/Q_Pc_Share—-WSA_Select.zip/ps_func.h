#ifndef PS_FUNC_H
#define PS_FUNC_H

#include <QByteArray>

class Ps_Func
{
public:
    Ps_Func();

public:
    virtual void dps_data(char* buf) = 0;

};

#endif // PS_FUNC_H
