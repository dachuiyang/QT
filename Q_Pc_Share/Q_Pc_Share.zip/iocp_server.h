#ifndef IOCP_SERVER_H
#define IOCP_SERVER_H


class Iocp_Server
{
public:
    Iocp_Server();
};

#endif // IOCP_SERVER_H